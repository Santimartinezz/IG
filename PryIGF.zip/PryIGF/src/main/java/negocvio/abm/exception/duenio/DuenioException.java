/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocvio.abm.exception.duenio;

/**
 *
 * @author Alumno
 */
public class DuenioException extends Exception{

    public DuenioException(String message) {
        super(message);
    }
    
}
