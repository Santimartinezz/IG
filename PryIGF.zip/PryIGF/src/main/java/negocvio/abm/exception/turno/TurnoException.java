/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocvio.abm.exception.turno;

/**
 *
 * @author Alumno
 */
public class TurnoException extends Exception{

    public TurnoException(String message) {
        super(message);
    }
    
}
