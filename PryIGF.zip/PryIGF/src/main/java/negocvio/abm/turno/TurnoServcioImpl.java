/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocvio.abm.turno;

import java.util.Date;
import java.util.List;
import modelo.turno.Turno;

/**
 *
 * @author Alumno
 */
public abstract class TurnoServcioImpl implements ITurno{

    

   
    
}
