/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo.mascota;

/**
 *
 * @author Alumno
 */
public interface IMascota {
    
    public static final char SEXO_FEMENINO='F';
    public static final char SEXO_MASCULINO='M';
    
    public boolean estaVacunado();
    
    public boolean esAdoptado();
    
            
}
